let token = sessionStorage.getItem("nyx_token") || "";
let projectsCache = [];
const $ = id => document.getElementById(id);
async function api(url, options = {}) {
  const res = await fetch(url, { ...options, headers: { "Content-Type":"application/json", ...(token ? {Authorization:"Bearer "+token}:{}), ...(options.headers||{}) }});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
function showNotice(message, bad=false){ $("notice").textContent=message; $("notice").style.color=bad?"#fca5a5":"#c4b5fd"; }
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function setLoggedIn(on){$("loginView").hidden=on;$("appView").hidden=!on;}
async function refreshAll(){
  const [stats,projects,users,keys]=await Promise.all([
    api("/api/admin/overview"),api("/api/admin/projects"),api("/api/admin/users"),api("/api/admin/keys")
  ]);
  $("sProjects").textContent=stats.projects;$("sUsers").textContent=stats.users;$("sActive").textContent=stats.activeLicenses;$("sUnused").textContent=stats.unusedKeys;
  projectsCache=projects;
  $("projects").innerHTML=projects.map(p=>`<div class="projectRow"><b>${escapeHtml(p.name)}</b><span>${escapeHtml(p.id)} · ${escapeHtml(p.description)}</span></div>`).join("") || '<p class="muted">No projects yet.</p>';
  $("keyProject").innerHTML=projects.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)}</option>`).join("");
  $("users").innerHTML=users.map(u=>`<tr><td>${escapeHtml(u.username)}</td><td>${escapeHtml(u.project_name)}</td><td class="${u.status==='active'?'status':''}">${escapeHtml(u.status)}</td><td>${escapeHtml(u.hwid_hash)}</td><td><button class="secondary" data-action="reset" data-id="${u.id}">Reset HWID</button><button class="${u.status==='active'?'danger':'secondary'}" data-action="${u.status==='active'?'revoke':'unrevoke'}" data-id="${u.id}">${u.status==='active'?'Revoke':'Restore'}</button></td></tr>`).join("") || '<tr><td colspan="5">No users yet.</td></tr>';
  $("keys").innerHTML=keys.map(k=>`<tr><td>${escapeHtml(k.project_name)}</td><td>${escapeHtml(k.username||"—")}</td><td>${escapeHtml(k.status)}</td><td>${k.expires_at?escapeHtml(new Date(k.expires_at).toLocaleDateString()):"Lifetime"}</td><td>${k.status!=="revoked"&&k.status!=="expired"?`<button class="danger" data-action="revoke-key" data-id="${k.id}">Revoke</button>`:"—"}</td></tr>`).join("") || '<tr><td colspan="5">No keys yet.</td></tr>';
}
$("loginForm").addEventListener("submit",async e=>{e.preventDefault();$("loginError").textContent="";try{const d=await api("/api/admin/login",{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})});token=d.token;sessionStorage.setItem("nyx_token",token);setLoggedIn(true);await refreshAll();}catch(err){$("loginError").textContent=err.message;}});
$("logout").onclick=()=>{token="";sessionStorage.removeItem("nyx_token");setLoggedIn(false);};
$("refresh").onclick=()=>refreshAll().catch(e=>showNotice(e.message,true));
$("projectForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/projects",{method:"POST",body:JSON.stringify({name:$("projectName").value,description:$("projectDesc").value})});$("projectForm").reset();await refreshAll();showNotice("Project created.");}catch(err){showNotice(err.message,true);}});
$("keyForm").addEventListener("submit",async e=>{e.preventDefault();try{const d=await api("/api/admin/keys",{method:"POST",body:JSON.stringify({projectId:$("keyProject").value,count:$("keyCount").value,days:$("keyDays").value})});$("newKeys").hidden=false;$("newKeys").innerHTML="<b>Copy these keys now. They are shown only once.</b>"+d.keys.map(k=>`<div class="keyLine">${escapeHtml(k.key)}</div>`).join("");await refreshAll();showNotice("Keys generated.");}catch(err){showNotice(err.message,true);}});
document.addEventListener("click",async e=>{const b=e.target.closest("button[data-action]");if(!b)return;const {action,id}=b.dataset;try{if(action==="reset")await api(`/api/admin/users/${id}/reset-hwid`,{method:"POST"});if(action==="revoke")await api(`/api/admin/users/${id}/revoke`,{method:"POST"});if(action==="unrevoke")await api(`/api/admin/users/${id}/unrevoke`,{method:"POST"});if(action==="revoke-key")await api(`/api/admin/keys/${id}/revoke`,{method:"POST"});await refreshAll();showNotice("Updated successfully.");}catch(err){showNotice(err.message,true);}});
if(token){setLoggedIn(true);refreshAll().catch(()=>{token="";sessionStorage.removeItem("nyx_token");setLoggedIn(false);});}